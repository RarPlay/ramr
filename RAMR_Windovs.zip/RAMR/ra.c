#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <curl/curl.h>
#include "miniz.h"
#include <jansson.h> // Для JSON (https://github.com/akheron/jansson)

#define MODULE_DIR "C:\\RAMR\\Module"
#define MODINFO_FILE "C:\\RAMR\\Module\\ModInfo.txt"

struct MemoryStruct {
    char *memory;
    size_t size;
};

// -------------------- Вспомогательные функции --------------------
static size_t write_memory(void *ptr, size_t size, size_t nmemb, void *userdata) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *)userdata;

    char *ptr_new = realloc(mem->memory, mem->size + realsize + 1);
    if(ptr_new == NULL) return 0; // ошибка
    mem->memory = ptr_new;

    memcpy(&(mem->memory[mem->size]), ptr, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

void make_dir(const char *path) {
#ifdef _WIN32
    _mkdir(path);
#else
    mkdir(path, 0755);
#endif
}

int download_file(const char *url, const char *outfilename) {
    CURL *curl = curl_easy_init();
    if (!curl) return 0;

    FILE *fp = fopen(outfilename, "wb");
    if (!fp) return 0;

    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_data);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);

    CURLcode res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
    fclose(fp);

    if(res != CURLE_OK) {
        printf("Ошибка скачивания: %s\n", curl_easy_strerror(res));
        return 0;
    }
    return 1;
}

int unzip_file(const char *zipfile, const char *dest) {
    mz_zip_archive zip_archive;
    memset(&zip_archive, 0, sizeof(zip_archive));
    if (!mz_zip_reader_init_file(&zip_archive, zipfile, 0)) return 0;

    int num_files = (int)mz_zip_reader_get_num_files(&zip_archive);
    for(int i=0; i<num_files; i++) {
        mz_zip_archive_file_stat file_stat;
        if(!mz_zip_reader_file_stat(&zip_archive, i, &file_stat)) continue;

        char full_path[512];
        snprintf(full_path, sizeof(full_path), "%s\\%s", dest, file_stat.m_filename);

        char *p = strrchr(full_path, '\\');
        if(p) { *p='\0'; make_dir(full_path); *p='\\'; }

        if(!mz_zip_reader_is_file_a_directory(&zip_archive, i))
            mz_zip_reader_extract_to_file(&zip_archive, i, full_path, 0);
        else
            make_dir(full_path);
    }

    mz_zip_reader_end(&zip_archive);
    return 1;
}

// -------------------- Версии --------------------
void parse_version(const char *str, int *major, int *minor, int *patch) {
    sscanf(str, "%d.%d.%d", major, minor, patch);
}

int version_compare(const char *v1, const char *v2) {
    int m1,n1,p1,m2,n2,p2;
    parse_version(v1,&m1,&n1,&p1);
    parse_version(v2,&m2,&n2,&p2);
    if(m1!=m2) return m1-m2;
    if(n1!=n2) return n1-n2;
    return p1-p2;
}

int get_installed_version(const char *mod_name, char *version_out, size_t size) {
    FILE *f=fopen(MODINFO_FILE,"r");
    if(!f) return 0;
    char line[256];
    while(fgets(line,sizeof(line),f)) {
        char name[128], version[64], deps[128];
        if(sscanf(line,"%127[^|]|%63[^|]|%127[^\n]", name, version, deps)>=2) {
            if(strcmp(name,mod_name)==0) {
                strncpy(version_out,version,size);
                fclose(f);
                return 1;
            }
        }
    }
    fclose(f);
    return 0;
}

void save_module_info(const char *mod_name,const char *version,const char *deps) {
    FILE *f=fopen(MODINFO_FILE,"a");
    if(!f) return;
    fprintf(f,"%s|%s|%s\n",mod_name,version,deps?deps:"");
    fclose(f);
}

// -------------------- Работа с сервером --------------------
int get_remote_version(const char *mod_name, char *version_out, size_t size) {
    char url[512];
    snprintf(url,sizeof(url),"http://ramrmod.duckdns.org/api/modules/%s.json",mod_name);

    CURL *curl=curl_easy_init();
    if(!curl) return 0;

    struct MemoryStruct chunk={0};
    curl_easy_setopt(curl,CURLOPT_URL,url);
    curl_easy_setopt(curl,CURLOPT_WRITEFUNCTION,write_memory);
    curl_easy_setopt(curl,CURLOPT_WRITEDATA,(void*)&chunk);

    CURLcode res=curl_easy_perform(curl);
    curl_easy_cleanup(curl);

    if(res!=CURLE_OK) {
        printf("Ошибка запроса версии: %s\n",curl_easy_strerror(res));
        return 0;
    }

    json_error_t error;
    json_t *root=json_loads(chunk.memory,0,&error);
    free(chunk.memory);
    if(!root) { printf("Ошибка разбора JSON\n"); return 0; }

    json_t *ver=json_object_get(root,"version");
    if(!ver) { json_decref(root); return 0; }

    const char *v=json_string_value(ver);
    if(v) strncpy(version_out,v,size);

    json_decref(root);
    return 1;
}

// -------------------- Установка/обновление --------------------
int install_module(const char *mod_name) {
    char version_local[64], version_remote[64];
    int installed=get_installed_version(mod_name,version_local,sizeof(version_local));
    if(!get_remote_version(mod_name,version_remote,sizeof(version_remote))) {
        printf("Не удалось получить версию с сервера.\n");
        return 0;
    }

    if(installed && version_compare(version_remote,version_local)<=0) {
        printf("Модуль %s уже актуален (версия %s)\n",mod_name,version_local);
        return 1;
    }

    printf(installed ? "Обновление модуля %s с %s до %s\n" : "Установка модуля %s (версия %s)\n",
        mod_name, installed?version_local:"", version_remote);

    char url[512], zip_path[512], target_dir[512];
    snprintf(url,sizeof(url),"http://ramrmod.duckdns.org/modules/%s.zip",mod_name);
    snprintf(zip_path,sizeof(zip_path),"%s\\%s.zip",MODULE_DIR,mod_name);
    snprintf(target_dir,sizeof(target_dir),"%s\\%s",MODULE_DIR,mod_name);

    make_dir(MODULE_DIR); make_dir(target_dir);

    if(!download_file(url,zip_path)) { printf("Не удалось скачать ZIP\n"); return 0; }
    if(!unzip_file(zip_path,target_dir)) { printf("Не удалось распаковать ZIP\n"); return 0; }

    remove(zip_path);
    save_module_info(mod_name,version_remote,NULL);
    printf("Модуль %s успешно установлен/обновлён!\n",mod_name);
    return 1;
}

// -------------------- Массовое обновление --------------------
void update_all() {
    FILE *f=fopen(MODINFO_FILE,"r");
    if(!f) { printf("Нет установленных модулей.\n"); return; }
    char line[256];
    while(fgets(line,sizeof(line),f)) {
        char name[128], version[64], deps[128];
        if(sscanf(line,"%127[^|]|%63[^|]|%127[^\n]", name, version, deps)>=2) {
            install_module(name);
        }
    }
    fclose(f);
}

// -------------------- Главная --------------------
int main(int argc,char *argv[]) {
    if(argc<2) {
        printf("Использование:\n ra install <модуль>\n ra update <модуль>\n ra update-all\n");
        return 1;
    }

    if(strcmp(argv[1],"install")==0 && argc==3) install_module(argv[2]);
    else if(strcmp(argv[1],"update")==0 && argc==3) install_module(argv[2]);
    else if(strcmp(argv[1],"update-all")==0) update_all();
    else printf("Неверная команда\n");

    return 0;
}
