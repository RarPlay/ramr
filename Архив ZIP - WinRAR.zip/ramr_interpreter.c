// ramr_interpreter_win_full.c - Полная версия для Windows
// Компиляция: gcc -std=c11 -O2 -o ramr_interpreter.exe ramr_interpreter_win_full.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

#ifdef _WIN32
#include <windows.h>
#include <conio.h>
#endif

#define MAX_LINE 1024
#define MAX_VARS 1024
#define MAX_FUNCTIONS 100
#define MAX_FUNC_LINES 50

typedef struct {
    char *key;
    char *value;
} Var;

typedef struct {
    char *name;
    char **lines;
    int line_count;
} Function;

static Var vars[MAX_VARS];
static int var_count = 0;
static Function functions[MAX_FUNCTIONS];
static int func_count = 0;
static int running = 1;
static int in_function_def = 0;
static char current_func_name[256] = "";
static char **function_lines = NULL;
static int function_line_count = 0;
static int skip_block = 0;
static int if_condition_met = 0;

// Утилиты работы с памятью
char *strdup_or_null(const char *s) {
    if (!s) return NULL;
    char *r = strdup(s);
    return r;
}

void set_var(const char *key, const char *value) {
    for (int i = 0; i < var_count; ++i) {
        if (strcmp(vars[i].key, key) == 0) {
            free(vars[i].value);
            vars[i].value = strdup_or_null(value);
            return;
        }
    }
    if (var_count < MAX_VARS) {
        vars[var_count].key = strdup_or_null(key);
        vars[var_count].value = strdup_or_null(value);
        var_count++;
    }
}

const char *get_var(const char *key) {
    for (int i = 0; i < var_count; ++i) {
        if (strcmp(vars[i].key, key) == 0) return vars[i].value;
    }
    return "";
}

// Простейший разбор строки: извлечь токен или строковый литерал в кавычках
char *next_token(char **line_ptr) {
    char *s = *line_ptr;
    if (!s) return NULL;
    while (*s && isspace((unsigned char)*s)) s++;
    if (*s == '\0') return NULL;
    
    char buf[MAX_LINE];
    buf[0] = '\0';
    
    if (*s == '"') {
        s++;
        char *d = buf;
        while (*s && *s != '"') {
            *d++ = *s++;
        }
        *d = '\0';
        if (*s == '"') s++;
        *line_ptr = s;
        return strdup_or_null(buf);
    } else {
        char *d = buf;
        while (*s && !isspace((unsigned char)*s)) {
            *d++ = *s++;
        }
        *d = '\0';
        *line_ptr = s;
        return strdup_or_null(buf);
    }
}

// Заменить {var} в строке на значение
char *substitute_vars(const char *input) {
    if (!input) return strdup_or_null("");
    
    char out[MAX_LINE * 2];
    out[0] = '\0';
    const char *p = input;
    
    while (*p) {
        if (*p == '{') {
            p++;
            char name[256];
            int ni = 0;
            while (*p && *p != '}' && ni < 255) name[ni++] = *p++;
            name[ni] = '\0';
            if (*p == '}') p++;
            const char *val = get_var(name);
            strncat(out, val, sizeof(out)-strlen(out)-1);
        } else {
            char tmp[2] = {*p, '\0'};
            strncat(out, tmp, sizeof(out)-strlen(out)-1);
            p++;
        }
    }
    return strdup_or_null(out);
}

// Random helpers
char *random_choice(char **items, int n) {
    if (n <= 0) return strdup_or_null("");
    int idx = rand() % n;
    return strdup_or_null(items[idx]);
}

char *random_text(int length) {
    if (length <= 0) length = 8;
    char *s = malloc(length + 1);
    for (int i = 0; i < length; ++i) s[i] = 'a' + (rand() % 26);
    s[length] = '\0';
    return s;
}

char *random_digits(int length) {
    if (length <= 0) length = 6;
    char *s = malloc(length + 1);
    for (int i = 0; i < length; ++i) s[i] = '0' + (rand() % 10);
    s[length] = '\0';
    return s;
}

// Проверка наличия ввода в stdin (Windows версия)
int stdin_has_data(void) {
#ifdef _WIN32
    return _kbhit();
#else
    struct timeval tv = {0, 0};
    fd_set fds;
    FD_ZERO(&fds);
    FD_SET(0, &fds);
    return select(1, &fds, NULL, NULL, &tv) > 0;
#endif
}

// Выполнение одной строки RAMR
void exec_line(char *line);

// Чтение файла в массив строк
char **read_file_lines(const char *path, int *out_count) {
    FILE *f = fopen(path, "r");
    if (!f) {
        *out_count = 0;
        return NULL;
    }
    
    char **lines = NULL;
    int cap = 0, cnt = 0;
    char buf[MAX_LINE];
    
    while (fgets(buf, sizeof(buf), f)) {
        size_t L = strlen(buf);
        while (L > 0 && (buf[L-1] == '\n' || buf[L-1] == '\r')) {
            buf[--L] = '\0';
        }
        if (cnt >= cap) {
            cap = cap ? cap * 2 : 64;
            lines = realloc(lines, cap * sizeof(char*));
        }
        lines[cnt++] = strdup_or_null(buf);
    }
    fclose(f);
    *out_count = cnt;
    return lines;
}

// Выполнить блок кода
void exec_block(char **lines, int start, int end) {
    for (int i = start; i < end && running; ++i) {
        exec_line(lines[i]);
    }
}

// Найти функцию по имени
Function* find_function(const char *name) {
    for (int i = 0; i < func_count; ++i) {
        if (strcmp(functions[i].name, name) == 0) {
            return &functions[i];
        }
    }
    return NULL;
}

// Выполнить функцию
void exec_function(const char *name) {
    Function *func = find_function(name);
    if (!func) {
        printf("[error] Функция '%s' не найдена\n", name);
        return;
    }
    
    for (int i = 0; i < func->line_count && running; ++i) {
        exec_line(func->lines[i]);
    }
}

// Загрузить модуль
void load_module(const char *module_name) {
    char filename[256];
    snprintf(filename, sizeof(filename), "%s.ramr", module_name);
    
    int line_count = 0;
    char **lines = read_file_lines(filename, &line_count);
    if (lines) {
        printf("[imp] Модуль '%s' загружен (%d строк)\n", module_name, line_count);
        exec_block(lines, 0, line_count);
        for (int i = 0; i < line_count; ++i) free(lines[i]);
        free(lines);
    } else {
        printf("[error] Модуль '%s' не найден\n", module_name);
    }
}

// Главная логика выполнения строки
void exec_line(char *line) {
    if (!line) return;
    
    // Пропускаем комментарии и пустые строки
    char *s = line;
    while (*s && isspace((unsigned char)*s)) s++;
    if (*s == '\0') return;
    if (*s == '@') return;

    // Обработка пропуска блоков для if/or
    if (skip_block) {
        if (strcmp(s, "or") == 0 && !if_condition_met) {
            skip_block = 0;
        } else if (strcmp(s, "end") == 0) {
            skip_block = 0;
            if_condition_met = 0;
        }
        return;
    }

    // Если мы внутри определения функции, сохраняем строки
    if (in_function_def) {
        if (strcmp(s, "end") == 0) {
            in_function_def = 0;
            if (func_count < MAX_FUNCTIONS) {
                functions[func_count].name = strdup_or_null(current_func_name);
                functions[func_count].lines = function_lines;
                functions[func_count].line_count = function_line_count;
                func_count++;
                printf("[def] Функция '%s' определена (%d строк)\n", current_func_name, function_line_count);
            }
            function_lines = NULL;
            function_line_count = 0;
            current_func_name[0] = '\0';
        } else {
            if (function_line_count < MAX_FUNC_LINES) {
                function_lines = realloc(function_lines, (function_line_count + 1) * sizeof(char*));
                function_lines[function_line_count++] = strdup_or_null(line);
            }
        }
        return;
    }

    char *p = s;
    char *cmd = next_token(&p);
    if (!cmd) return;

    // Обработка print.<n> и print.Infinity
    if (strncmp(cmd, "print.", 6) == 0) {
        char *arg = next_token(&p);
        if (!arg) arg = strdup_or_null("");
        
        if (strcmp(cmd, "print.Infinity") == 0) {
            while (running) {
                char *out = substitute_vars(arg);
                printf("%s\n", out);
                free(out);
                fflush(stdout);
                
#ifdef _WIN32
                Sleep(1000);
#else
                sleep(1);
#endif
                
                if (stdin_has_data()) {
                    int ch = getchar();
                    if (ch == 'q' || ch == 'Q') break;
                }
            }
            free(arg); free(cmd);
            return;
        } else {
            int n = atoi(cmd + 6);
            for (int i = 0; i < n; ++i) {
                char *out = substitute_vars(arg);
                printf("%s\n", out);
                free(out);
            }
            free(arg); free(cmd);
            return;
        }
    }

    if (strcmp(cmd, "print") == 0) {
        char *arg = next_token(&p);
        if (!arg) arg = strdup_or_null("");
        char *out = substitute_vars(arg);
        printf("%s\n", out);
        free(out); free(arg); free(cmd);
        return;
    }

    if (strcmp(cmd, "rprint") == 0) {
        char *arg = next_token(&p);
        if (!arg) arg = strdup_or_null("");
        char *out = substitute_vars(arg);
        printf("%s\n", out);
        free(out); free(arg); free(cmd);
        return;
    }

    if (strcmp(cmd, "type") == 0) {
        char *prompt = next_token(&p);
        if (!prompt) prompt = strdup_or_null("");
        char *out_prompt = substitute_vars(prompt);
        printf("%s", out_prompt);
        fflush(stdout);
        
        char buf[MAX_LINE];
        if (!fgets(buf, sizeof(buf), stdin)) buf[0] = '\0';
        size_t L = strlen(buf); 
        while (L>0 && (buf[L-1]=='\n' || buf[L-1]=='\r')) buf[--L] = '\0';
        
        set_var("last_input", buf);
        free(prompt); free(out_prompt); free(cmd);
        return;
    }

    if (strcmp(cmd, "save") == 0) {
        char *name = next_token(&p);
        char *value = next_token(&p);
        
        if (!name) { 
            free(cmd); 
            return; 
        }
        
        if (!value) {
            value = strdup_or_null(get_var("last_input"));
        } else {
            char *subst_value = substitute_vars(value);
            free(value);
            value = subst_value;
        }
        
        set_var(name, value);
        free(name); free(value); free(cmd);
        return;
    }

    if (strcmp(cmd, "imp") == 0) {
        char *mod = next_token(&p);
        if (mod) {
            load_module(mod);
        }
        free(mod); free(cmd);
        return;
    }
    
    if (strcmp(cmd, "start") == 0) {
        char *mod = next_token(&p);
        if (mod) {
            exec_function(mod);
        }
        free(mod); free(cmd);
        return;
    }
    
    if (strcmp(cmd, "off") == 0) {
        char *mod = next_token(&p);
        free(mod); free(cmd);
        return;
    }

    if (strcmp(cmd, "query") == 0) {
        char *mod = next_token(&p);
        char *q = next_token(&p);
        free(mod); free(q); free(cmd);
        return;
    }

    if (strcmp(cmd, "wait()") == 0 || strcmp(cmd, "wait") == 0) {
        printf("Нажмите Enter чтобы продолжить..."); 
        fflush(stdout);
        char buf[16]; 
        fgets(buf, sizeof(buf), stdin);
        free(cmd);
        return;
    }

    if (strcmp(cmd, "exit") == 0) {
        running = 0; free(cmd); return;
    }

    if (strcmp(cmd, "break") == 0) {
        running = 0; free(cmd); return;
    }

    if (strcmp(cmd, "and") == 0) {
        char *next_cmd;
        while ((next_cmd = next_token(&p)) != NULL) {
            exec_line(next_cmd);
            free(next_cmd);
        }
        free(cmd);
        return;
    }

    if (strcmp(cmd, "def") == 0) {
        char *name = next_token(&p);
        if (!name) {
            free(cmd);
            return;
        }
        
        in_function_def = 1;
        strncpy(current_func_name, name, sizeof(current_func_name)-1);
        function_lines = NULL;
        function_line_count = 0;
        free(name); free(cmd);
        return;
    }

    if (strcmp(cmd, "random.choice") == 0) {
        char *items[128]; int ni = 0;
        char *t;
        while ((t = next_token(&p)) != NULL) {
            items[ni++] = t;
            if (ni >= 128) break;
        }
        char *res = random_choice(items, ni);
        printf("%s\n", res);
        free(res);
        for (int i = 0; i < ni; ++i) free(items[i]);
        free(cmd);
        return;
    }

    if (strcmp(cmd, "random.text") == 0) {
        char *len_s = next_token(&p);
        int len = len_s ? atoi(len_s) : 8;
        char *res = random_text(len);
        printf("%s\n", res);
        free(res); free(len_s); free(cmd);
        return;
    }

    if (strcmp(cmd, "random.digits") == 0) {
        char *len_s = next_token(&p);
        int len = len_s ? atoi(len_s) : 6;
        char *res = random_digits(len);
        printf("%s\n", res);
        free(res); free(len_s); free(cmd);
        return;
    }

    if (strcmp(cmd, "if") == 0) {
        char *varname = next_token(&p);
        char *op = next_token(&p);
        char *val = next_token(&p);
        int cond = 0;
        const char *left = get_var(varname);
        
        if (op && strcmp(op, "==") == 0) {
            cond = (strcmp(left, val ? val : "") == 0);
        }
        
        if (!cond) {
            skip_block = 1;
            if_condition_met = 0;
        } else {
            if_condition_met = 1;
        }
        
        free(varname); free(op); free(val); free(cmd);
        return;
    }

    if (strcmp(cmd, "or") == 0) {
        if (skip_block && !if_condition_met) {
            skip_block = 0;
        }
        free(cmd);
        return;
    }

    if (strcmp(cmd, "end") == 0) {
        skip_block = 0;
        if_condition_met = 0;
        free(cmd);
        return;
    }

    // Если команда не распознана, пытаемся выполнить как функцию
    exec_function(cmd);
    free(cmd);
}

int main(int argc, char **argv) {
    srand((unsigned)time(NULL));
    char *script = NULL;
    if (argc >= 2) script = argv[1];

#ifdef _WIN32
    SetConsoleOutputCP(65001);
    SetConsoleCP(65001);
#endif

    if (script) {
        int line_count = 0;
        char **lines = read_file_lines(script, &line_count);
        if (!lines) {
            printf("Ошибка: не удалось открыть файл '%s'\n", script);
            return 1;
        }
        
        for (int i = 0; i < line_count && running; ++i) {
            exec_line(lines[i]);
        }
        
        for (int i = 0; i < line_count; ++i) free(lines[i]); 
        free(lines);
        return 0;
    }

    printf("RAMR interpreter (Windows). Type 'exit' to quit.\n");
    char buf[MAX_LINE];
    
    while (running) {
        printf("> "); 
        fflush(stdout);
        if (!fgets(buf, sizeof(buf), stdin)) break;
        
        size_t L = strlen(buf); 
        while (L>0 && (buf[L-1]=='\n' || buf[L-1]=='\r')) buf[--L] = '\0';
        exec_line(buf);
    }

    for (int i = 0; i < var_count; ++i) {
        free(vars[i].key); 
        free(vars[i].value);
    }
    
    for (int i = 0; i < func_count; ++i) {
        free(functions[i].name);
        for (int j = 0; j < functions[i].line_count; ++j) {
            free(functions[i].lines[j]);
        }
        free(functions[i].lines);
    }
    
    return 0;
}
